const Sobre = () => {
  return <h1> Sobre </h1>;
};

export default Sobre;
